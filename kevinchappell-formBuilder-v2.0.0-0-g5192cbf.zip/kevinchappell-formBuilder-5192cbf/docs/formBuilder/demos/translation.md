# Translation

Translate formBuilder to any language through the configuration property `messages`.
<p data-height="580" data-theme-id="22927" data-slug-hash="PNZZmw" data-default-tab="result" data-user="kevinchappell" class="codepen"></p>
