# dataType
Use formBuilder with XML or JSON data

## Usage
```javascript
var options = {
      dataType: 'json' // default: 'xml' 
    };
$(container).formBuilder(options);
```
<p data-height="525" data-embed-version="2" data-theme-id="22927" data-slug-hash="ozNAod" data-default-tab="js,result" data-user="kevinchappell" class="codepen"></p>
