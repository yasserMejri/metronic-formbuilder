# typeUserAttrs
Define custom attributes for field types with this handy option.

## Usage
<p data-height="525" data-embed-version="2" data-theme-id="22927" data-slug-hash="yaJbZZ" data-default-tab="js,result" data-user="kevinchappell" class="codepen"></p>
